﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace up_pr6
{
    /// <summary>
    /// Логика взаимодействия для pr6_2.xaml
    /// </summary>
    public partial class pr6_2 : Window
    {
        public pr6_2()
        {
            InitializeComponent();
            TextBox1.TextChanged += UpdateCloseButtonState;
            TextBox2.TextChanged += UpdateCloseButtonState;
            ThemeSelector.SelectionChanged += ApplySelectedTheme;
        }

        private void UpdateCloseButtonState(object sender, TextChangedEventArgs e)
        {
            CloseButton.IsEnabled = string.IsNullOrWhiteSpace(TextBox1.Text) &&
                                    string.IsNullOrWhiteSpace(TextBox2.Text);
        }

        private void ApplySelectedTheme(object sender, SelectionChangedEventArgs e)
        {
            if (ThemeSelector.SelectedItem is ComboBoxItem selectedItem && selectedItem.Tag is string tag)
            {
                var parts = tag.Split(',');
                if (parts.Length == 3)
                {
                    try
                    {
                        var fontFamily = new FontFamily(parts[0]);
                        double fontSize = double.Parse(parts[1]);
                        var foreground = (SolidColorBrush)new BrushConverter().ConvertFromString(parts[2]);

                        TextBox1.FontFamily = fontFamily;
                        TextBox1.FontSize = fontSize;
                        TextBox1.Foreground = foreground;

                        TextBox2.FontFamily = fontFamily;
                        TextBox2.FontSize = fontSize;
                        TextBox2.Foreground = foreground;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка применения стиля: " + ex.Message);
                    }
                }
            }
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Открыть");
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            TextBox1.Clear();
            TextBox2.Clear();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void TextBox1_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
