﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace up_pr4_5
{
    /// <summary>
    /// Логика взаимодействия для pr5.xaml
    /// </summary>
    public partial class pr5 : Window
    {
        public pr5()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            pr5_1 pr5_1 = new pr5_1();
            pr5_1.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            pr5_2 pr5_2 = new pr5_2();
            pr5_2.Show();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            pr5_3 pr5_3 = new pr5_3();
            pr5_3.Show();
        }
    }
}
