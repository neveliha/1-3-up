﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Controls;
using System.Windows.Ink;
namespace up_pr4_5
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private InkCanvasEditingMode _editingMode;
        public InkCanvasEditingMode EditingMode
        {
            get => _editingMode;
            set
            {
                _editingMode = value;
                OnPropertyChanged();
            }
        }

        public List<InkCanvasEditingMode> EditingModes { get; } = new List<InkCanvasEditingMode>
        {
            InkCanvasEditingMode.Ink,
            InkCanvasEditingMode.Select,
            InkCanvasEditingMode.EraseByPoint,
            InkCanvasEditingMode.EraseByStroke
        };

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
