﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace up_pr4_5
{
    public partial class pr4_4 : Window
    {
        public pr4_4()
        {
            InitializeComponent();
            DataContext = new MainViewModel();
        }
    }
}