﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace up_pr4_5
{
    /// <summary>
    /// Логика взаимодействия для pr4_2.xaml
    /// </summary>
    public partial class pr4_2 : Window
    {
        public pr4_2()
        {
            InitializeComponent();
        }
    }
}
